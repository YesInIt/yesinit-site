(function () {
    "use strict";

    /* ---------- mobile sidebar ---------- */

    var toggle = document.getElementById("sidebarToggle");
    var sidebar = document.getElementById("sidebar");
    var overlay = document.getElementById("sidebarOverlay");

    if (toggle && sidebar && overlay) {
        var closeSidebar = function () {
            sidebar.classList.remove("is-open");
            overlay.classList.remove("is-visible");
            toggle.setAttribute("aria-expanded", "false");
            document.body.classList.remove("no-scroll");
        };

        var openSidebar = function () {
            sidebar.classList.add("is-open");
            overlay.classList.add("is-visible");
            toggle.setAttribute("aria-expanded", "true");
            document.body.classList.add("no-scroll");
        };

        toggle.addEventListener("click", function () {
            if (sidebar.classList.contains("is-open")) {
                closeSidebar();
            } else {
                openSidebar();
            }
        });

        overlay.addEventListener("click", closeSidebar);

        document.addEventListener("keydown", function (e) {
            if (e.key === "Escape") {
                closeSidebar();
            }
        });

        var mq = window.matchMedia("(min-width: 960px)");
        var handleChange = function (e) {
            if (e.matches) {
                closeSidebar();
            }
        };
        if (mq.addEventListener) {
            mq.addEventListener("change", handleChange);
        } else if (mq.addListener) {
            mq.addListener(handleChange);
        }
    }

    /* ---------- share row (страница поста) ---------- */

    var shareRow = document.querySelector(".share-row");

    if (shareRow) {
        var shareUrl = shareRow.getAttribute("data-share-url") || window.location.href;
        var shareTitle = shareRow.getAttribute("data-share-title") || document.title;

        var xLink = shareRow.querySelector(".share-x");
        if (xLink) {
            xLink.href = "https://twitter.com/intent/tweet?url=" + encodeURIComponent(shareUrl) +
                "&text=" + encodeURIComponent(shareTitle);
        }

        var tgLink = shareRow.querySelector(".share-tg");
        if (tgLink) {
            tgLink.href = "https://t.me/share/url?url=" + encodeURIComponent(shareUrl) +
                "&text=" + encodeURIComponent(shareTitle);
        }

        var copyBtn = shareRow.querySelector(".share-copy");
        if (copyBtn) {
            var copyLabel = copyBtn.querySelector("span");
            var defaultLabel = copyLabel ? copyLabel.textContent : "";

            copyBtn.addEventListener("click", function () {
                var done = function () {
                    copyBtn.classList.add("is-copied");
                    if (copyLabel) {
                        copyLabel.textContent = "Скопировано";
                    }
                    setTimeout(function () {
                        copyBtn.classList.remove("is-copied");
                        if (copyLabel) {
                            copyLabel.textContent = defaultLabel;
                        }
                    }, 1600);
                };

                if (navigator.clipboard && navigator.clipboard.writeText) {
                    navigator.clipboard.writeText(shareUrl).then(done, function () {
                        fallbackCopy(shareUrl);
                        done();
                    });
                } else {
                    fallbackCopy(shareUrl);
                    done();
                }
            });
        }
    }

    function fallbackCopy(text) {
        var input = document.createElement("textarea");
        input.value = text;
        input.setAttribute("readonly", "");
        input.style.position = "absolute";
        input.style.left = "-9999px";
        document.body.appendChild(input);
        input.select();
        try {
            document.execCommand("copy");
        } catch (err) {
            /* noop — clipboard not available */
        }
        document.body.removeChild(input);
    }
})();
